//intensit� de la gravit�
var gravity = 1200;

//hauteur de saut (plus la valeur est n�gative, plus le saut est haut)
var heightJump = -720;

//vitesse de d�placement du personnage
var speed = 300;

//couleur de fond
var bgColor = "#000000";